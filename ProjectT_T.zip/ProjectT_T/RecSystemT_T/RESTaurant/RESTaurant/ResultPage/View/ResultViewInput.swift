import UIKit

protocol ResultViewInput: AnyObject {
    func showRestaurants(_ restaurants: [Restaurant])
}

protocol ResultPresenterInput {
    func viewDidLoad()
    func didTapBackButton()
    func didSelectRestaurant(_ restaurant: Restaurant)
}

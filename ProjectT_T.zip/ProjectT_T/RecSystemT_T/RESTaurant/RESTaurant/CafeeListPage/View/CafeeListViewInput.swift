protocol CafeeListViewInput {
    func reloadData()
    func showError(message: String)
}

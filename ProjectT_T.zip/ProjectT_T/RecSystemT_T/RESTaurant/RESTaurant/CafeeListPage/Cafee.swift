/*struct Cafee {
    let name: String
    let metro: String
    let imageName: String
}
*/

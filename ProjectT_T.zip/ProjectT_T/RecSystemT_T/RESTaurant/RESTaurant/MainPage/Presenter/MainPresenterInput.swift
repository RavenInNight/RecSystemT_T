protocol MainPresenterInput: AnyObject {
    func didSelectCuisines(_ cuisines: [String])
}

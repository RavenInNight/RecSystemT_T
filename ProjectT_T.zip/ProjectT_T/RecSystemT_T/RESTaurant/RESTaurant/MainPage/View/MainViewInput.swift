import UIKit

protocol MainViewInput {
    func getNextColor() -> UIColor
}

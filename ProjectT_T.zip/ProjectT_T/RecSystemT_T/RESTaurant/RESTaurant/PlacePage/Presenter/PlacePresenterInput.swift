protocol PlacePresenterInput {
    func viewDidLoad()
}

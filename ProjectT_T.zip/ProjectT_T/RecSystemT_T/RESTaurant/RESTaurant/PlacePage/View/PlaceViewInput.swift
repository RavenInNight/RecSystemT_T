import UIKit

protocol PlaceViewInput {
    func showRestaurantDetails(_ restaurant: Restaurant)
}
